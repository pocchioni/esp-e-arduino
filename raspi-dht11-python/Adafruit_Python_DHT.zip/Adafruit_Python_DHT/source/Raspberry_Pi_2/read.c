#include "pi_2_dht_read.h"
#include "pi_2_mmio.h"
#include <stdio.h>

void main(){

float hum, temp;
pi_2_dht_read(22, 22, &hum, &temp);
printf("Temp = %f   Hum = %f \n", temp, hum );

}
